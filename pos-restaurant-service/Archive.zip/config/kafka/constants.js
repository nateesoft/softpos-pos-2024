const TOPIC_NAME = "my-topic"
const GROUP_ID = "test-group"
const CLIENT_ID = "nodejs-kafka"
const BROKERS = ["127.0.0.1:9092"]

module.exports = {
    TOPIC_NAME,
    GROUP_ID,
    CLIENT_ID,
    BROKERS
}