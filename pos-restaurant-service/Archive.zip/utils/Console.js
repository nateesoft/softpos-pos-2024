const log = (data, print = true) => {
    if (print) {
        console.log(data)
    }
}

module.exports = {
    log
}